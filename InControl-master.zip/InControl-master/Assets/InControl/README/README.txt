## InControl

Documentation and additional information is available online at:
http://www.gallantgames.com/incontrol

## JavaScript

InControl is written in C#, but it can also be used with JavaScript. To access it from JavaScript, create a folder under the 'Assets' folder named 'Plugins' and move the 'InControl' folder inside. You will also need to add 'import InControl;' to the top of your JavaScript files. For projects using InControl from C#, none of this is necessary. For more information, please see the [Unity documentation on Special Folders and Script Compilation Order at http://docs.unity3d.com/Documentation/Manual/ScriptCompileOrderFolders.html

